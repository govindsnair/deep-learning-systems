import helpers as h
import sklearn
import sklearn.datasets
import sklearn.linear_model
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# Read the data
data = h.read_data()
print (data)

# Split the data into train and test
train, test = train_test_split(data, test_size=0.3)

# Create and train the model
model = sklearn.linear_model.LogisticRegressionCV();
model.fit(train[['x1', 'x2']], train['label']);

# Predict the values using trained model
predictions_train = model.predict(train[['x1', 'x2']])
predictions_test = model.predict(test[['x1', 'x2']])

# Accuracy calculations
accuracy_train = accuracy_score(train['label'], predictions_train) * 100
accuracy_test = accuracy_score(test['label'], predictions_test) * 100

print ('Train accuracy: %d %%' % accuracy_train)
print ('Test accuracy: %d %%' % accuracy_test)

