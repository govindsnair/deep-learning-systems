import helper as h
import sklearn
import sklearn.datasets
import sklearn.linear_model
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# Task 1: Read and visualise the data
data = h.read_data()
print (data)

# Task 2: Split the data into train and test with 70:30 and 50:50 ratios

train70, test30 = train_test_split(data, test_size=0.3)
train50, test50 = train_test_split(data, test_size=0.5)

# Task 3: Create and train three models

model70 = sklearn.linear_model.LogisticRegressionCV();
model70.fit(train70[['x1', 'x2']], train70['label']);

model50 = sklearn.linear_model.LogisticRegressionCV();
model50.fit(train50[['x1', 'x2']], train50['label']);

model100 = sklearn.linear_model.LogisticRegressionCV();
model100.fit(data[['x1', 'x2']], data['label']);

predictions_train70 = model70.predict(train70[['x1', 'x2']])
predictions_test70 = model70.predict(test30[['x1', 'x2']])
predictions_train50 = model50.predict(train50[['x1', 'x2']])
predictions_test50 = model50.predict(test50[['x1', 'x2']])
predictions_train100 = model100.predict(data[['x1', 'x2']])

accuracy_train70 = accuracy_score(train70['label'], predictions_train70) * 100
accuracy_test70 = accuracy_score(test30['label'], predictions_test70) * 100
accuracy_train50 = accuracy_score(train50['label'], predictions_train50) * 100
accuracy_test50 = accuracy_score(test50['label'], predictions_test50) * 100
accuracy_train100 = accuracy_score(data['label'], predictions_train100) * 100


print ('Train accuracy 70-30: %d %%' % accuracy_train70)
print ('Test accuracy 70-30: %d %%' % accuracy_test70)
print ('Train accuracy 50-50: %d %%' % accuracy_train50)
print ('Test accuracy 50-50: %d %%' % accuracy_test50)
print ('Train accuracy 100-0: %d %%' % accuracy_train100)
